import { useState } from 'react';
import './App.css';
import Task1 from './Component/Task1';
import Task2 from './Component/Task2';
import FormData from './Component/Task4/FormData';
import Task5 from './Component/Task5/Task5';

function App() {
  const [users, setUsers] = useState([]);
  const handleNewItem = (newUser) => {
    setUsers([...users, newUser]);
  };
  return (

    <div className='bg-blue-100 flex flex-col justify-center items-center'>
      <Task1 />
      <Task2 />
      <FormData onNewItem={handleNewItem} users={users} />
      <Task5/>
    </div>
  );
}

export default App;
