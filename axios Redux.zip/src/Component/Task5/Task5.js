import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getData, postData } from './FetchedSlice/FetchedSlice';

const Task5 = () => {
    const [mydata, setMydata] = useState({
        title: '',
        body: ''
    });
    const dispatch = useDispatch();
    const { data, load, err } = useSelector(state => state.fetchingApi);
    console.log('mydata', data);
    const handlesubmit = (e) => {
        e.preventDefault();
        dispatch(postData(mydata))
        dispatch(getData())
        setMydata({
            title: '',
            body: ''
        })
    }
    const handleInput = (e) => {
        const { name, value } = e.target
        setMydata({ ...mydata, [name]: value })
    }
    return (
        <div className='bg-emerald-300 flex flex-col gap-4 justify-center items-center'>
             <div>
                <h1 className='text-2xl'>Task No 5-Redux to store the fetched data and manage API-related actions</h1>
            </div>
            <div>
                <div>
                    <button onClick={() => dispatch(getData())} className='px-4 py-2 bg-blue-500 rounded'>Fetch Data</button>
                </div>
                <div>
                    {load && <p>Loading...</p>}
                    {err && <p>Error fetching data</p>}
                </div>
                <div className='flex flex-col gap-6'>
                    {Array.isArray(data) && data.length > 0 ? (
                        data.map((item) => (
                            <div key={item.id} className='bg-emerald-200'>
                                <h1>{item.title}</h1>
                                <h2>{item.body}</h2>
                            </div>
                        ))
                    ) : (
                        <p>No data available</p>
                    )}
                </div>
            </div>
            <div>
                <form onSubmit={handlesubmit} className='flex flex-col gap-2 my-3 items-center'>
                    <div>
                        <input type="text" placeholder='title' name='title' value={mydata.title} onChange={handleInput} />
                    </div>
                    <div>
                        <input type="text" placeholder='body' name='body' value={mydata.body} onChange={handleInput} />
                    </div>
                    <div>
                        <button type='submit' className='px-4 py-2 bg-blue-500 rounded'>send to the api</button>
                    </div>
                </form>
            </div>
        </div>
    )
}

export default Task5
