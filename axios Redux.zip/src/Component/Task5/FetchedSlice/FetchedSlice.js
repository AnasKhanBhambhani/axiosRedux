import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
export const getData = createAsyncThunk('fetchdata', async () => {
    const response = await axios.get('https://assignmentenegmaticx.free.beeceptor.com/api/users');
    return response.data;
});
export const postData = createAsyncThunk('postdata', async (newData) => {
    const response = await axios.post('https://assignmentenegmaticx.free.beeceptor.com/api/users', newData);
    return response.data;
});
const handleAsyncActions = (builder, thunk) => {
    builder
        .addCase(thunk.pending, (state) => {
            state.load = true;
            state.err = false;
        })
        .addCase(thunk.fulfilled, (state, action) => {
            state.load = false;
            state.data = action.payload;
            state.err = false;
        })
        .addCase(thunk.rejected, (state) => {
            state.load = false;
            state.err = true;
        });
};
export const FetchedSlice = createSlice({
    name: 'fetchingApi',
    initialState: {
        load: false,
        data: [],
        err: false,
    },
    reducers: {},
    extraReducers: (builder) => {
        handleAsyncActions(builder, getData);
        handleAsyncActions(builder, postData);
    }
})
export default FetchedSlice.reducer