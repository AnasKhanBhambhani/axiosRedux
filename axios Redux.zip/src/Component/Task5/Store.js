import { configureStore } from "@reduxjs/toolkit";
import fetchedReducer from './FetchedSlice/FetchedSlice'
const store = configureStore({
    reducer: {
        fetchingApi: fetchedReducer
    }
})
export default store 