import axios from 'axios';
import React, { useEffect, useState } from 'react'

const FormData = ({ onNewItem, users }) => {
    const [data, setData] = useState({
        title: '',
        body: ''
    });
    const [submitt, setSubmitt] = useState(false);
    const handleinput = (e) => {
        const { name, value } = e.target;
        setData({ ...data, [name]: value })
    }
    const handleSubmit = () => {
        console.log(data);
        axios.post('https://assignmentenegmatixx.free.beeceptor.com/api/users', data)
            .then(res => {
                console.log('Form submitted successfully:', res.data);
                setData({
                    title: '',
                    body: ''
                })
                onNewItem(res.data);
            })
            .catch(err => {
                console.log(err.message);
            })
    }
    const formSubmit = (e) => {
        e.preventDefault();
        setSubmitt(true);
    }
    useEffect(() => {
        if (submitt) {
            handleSubmit();
        }
    }, [submitt])
    return (
        <div className='flex flex-col'>
               <div>
                <h1 className='text-2xl'>Task No 4-Advanced API Calls</h1>
            </div>
         <div>
         <form className='flex flex-col gap-6 items-center' onSubmit={formSubmit}>
                <div>
                    <h1 className='text-2xl'>Form To send data to the api</h1>
                </div>
                <div>
                    <input type="text" id='title' name='title' value={data.title} onChange={handleinput} placeholder='Enter Your title Here' />
                </div>
                <div>
                    <textarea id="body" name="body" value={data.body} onChange={handleinput} rows="4" cols="22" placeholder='Enter Your detail Here'>
                        At w3schools.com you will learn how to make a website. They offer free tutorials in all web development technologies.
                    </textarea>
                </div>
                <div>
                    <button className='bg-blue-600 rounded px-4 py-2' type='submit'>send it</button>
                </div>
            </form>
         </div>
         <div>
         {users.map((item) => {
                    return (
                        <div key={item.id} className='bg-emerald-200 w-52 p-5'>
                            <h1>{item.title}</h1>
                            <h1>{item.body}</h1>

                        </div>
                    )
                })

                }
         </div>
        </div>
    )
}

export default FormData
