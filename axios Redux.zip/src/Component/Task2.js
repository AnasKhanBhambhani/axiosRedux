import axios from 'axios'
import React, { useEffect, useState } from 'react'

const Task2 = () => {
    const [mypost, setmypost] = useState([]);
    const [error, setError] = useState(null);
    const [load, setLoad] = useState(true);

    useEffect(() => {
        const fetchingData = async () => {
            try {
                let response = await axios.get('https://assignmentenegmaticx.free.beeceptor.com/api/users');
                setmypost(response.data)
                setLoad(false);
            } catch (error) {
                setError(error.message)
                setLoad(false);

            }
        }
        fetchingData();
    }, [])
    return (
        <div className='flex flex-col flex-wrap gap-2 items-center my-3'>
            <div>
                <h1 className='text-2xl'>Task No 2 ( Dynamic Content Rendering ) & Task 3 ( Loading State and Error Handling )</h1>
            </div>

            <div>
                {load && <h1>data is being fetched....</h1>}
            </div>
            <div>
                {error && <h1>{error}</h1>}
            </div>
            <div>
                <ul className='flex flex-wrap  gap-2 justify-center'>
                    {mypost.slice(0, 50).map((item) => {
                        return (
                            <li key={item.id} className='bg-emerald-200 w-52  p-4 flex flex-col gap-5'>
                                <h1 className='text-xl'>  {item.title}</h1>
                                <p>{item.body}</p>
                            </li>
                        )
                    })
                    }

                </ul>
            </div>
        </div>
    )
}
export default Task2
